package org.springframework.jdbc.core;

public @interface JdbcTemplate {

}
