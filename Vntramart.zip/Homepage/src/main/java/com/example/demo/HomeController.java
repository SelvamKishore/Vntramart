package com.example.demo;
import java.util.*;
import java.text.DecimalFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import java.io.*;
import java.sql.*;

@Controller


public class HomeController {
@RequestMapping("/")
public ModelAndView enter() {
return new ModelAndView("home");
}
@RequestMapping("/login")
public ModelAndView login(HttpServletRequest req , HttpServletResponse res) throws IOException{
return new ModelAndView("login");
}
   @RequestMapping("/neww")
   public ModelAndView neww() {
   return new ModelAndView("neww");
   }


   @RequestMapping("/check")
   public ModelAndView check(HttpServletRequest req, HttpServletResponse res) {
   try{
      String username =req.getParameter("id"); 
      System.out.println(username);
      String password = req.getParameter("password");
      String rpassword=req.getParameter("rpassword");
      if(password.equals(rpassword)) {
      System.out.print("Pass match");
      Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
      Connection conn=DriverManager.getConnection(  
       "jdbc:mysql://localhost:3306/logins","root","Kishore@123");
     
      PreparedStatement pst = conn.prepareStatement("Select id,password from logins.login_details");
      ResultSet rs = pst.executeQuery();
      while(rs.next()){
       if (rs.getString("id").equals(username)){
       return new ModelAndView("welcome");
       }
      }
      pst = conn.prepareStatement("INSERT INTO logins.login_details (id,password)VALUES (?,?)");
      pst.setString(1, username);
      pst.setString(2, password);
      int n=pst.executeUpdate();
      }
      else {
    	  System.out.print("pass not match");
     return new ModelAndView("passalert");
      }
     
   }
      catch (Exception e) {
System.out.print(e);
}
   return new ModelAndView("home");
   }
@RequestMapping("/validate")
public ModelAndView test(HttpServletRequest req , HttpServletResponse res) throws IOException{
try{
      String username = req.getParameter("username");  
      String password = req.getParameter("password");
      Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
      Connection conn=DriverManager.getConnection(  
       "jdbc:mysql://localhost:3306/logins","root","Kishore@123");      
      PreparedStatement pst = conn.prepareStatement("Select id,password from logins.login_details where id=? and password=?");
      pst.setString(1, username);
      pst.setString(2, password);
      ResultSet rs = pst.executeQuery();    
      if(rs.next()) {
       return new ModelAndView("welcome");
      }
     
      else {
          return new ModelAndView("home1");
         
      }
 }
 catch(Exception e){      
 System.out.print(e);
 return new ModelAndView("home1");
 }      


}


@RequestMapping("/c-page")
public ModelAndView cartp1() {
return new ModelAndView("c1");
}


@RequestMapping("/cart-page")
public ModelAndView cart_page() {
return new ModelAndView("cc");
}


@RequestMapping("/billadd")
public ModelAndView billaddnew() {
return new ModelAndView("bb");
}


@RequestMapping("/tq")
public ModelAndView finalpage() {
return new ModelAndView("dd");
}

}